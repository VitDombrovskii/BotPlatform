# StrategyContext placeholder
