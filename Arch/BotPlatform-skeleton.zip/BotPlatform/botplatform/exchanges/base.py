# Exchange adapter base
